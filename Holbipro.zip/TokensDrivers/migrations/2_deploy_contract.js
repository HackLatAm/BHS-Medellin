var DriverP = artifacts.require("DriverP");

module.exports = function(deployer) {
  deployer.deploy(DriverP);
};