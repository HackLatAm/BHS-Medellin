# Tokens Drive

## Contributors

- Giovanni Perez
- Andres Garcia
- Lina Montaño

# Instalacion

```bash
npm i
```
```bash
npm run dev
```

# Tecnologias

- JavaScript
- HTML
- RSK testnet
- JQUERY

# Slides
https://slides.com/calypsobronte/hack-tokes-driver/live?context=editing#/

# Zip
